
import custom_params
custom_params.filename = 'fig7'
import params
import runsim
runsim.build_complete_model('c10.dic')
runsim.run()

